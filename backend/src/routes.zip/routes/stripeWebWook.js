// routes/webhookPagamentos.js
import express from "express";
import Stripe from "stripe";
import { PrismaClient, Prisma } from "@prisma/client";
import dotenv from "dotenv";

dotenv.config();

const router = express.Router();
const prisma = new PrismaClient();

const stripeKey = process.env.STRIPE_SECRET_KEY;
if (!stripeKey) throw new Error("STRIPE_SECRET_KEY não configurada");
const stripe = new Stripe(stripeKey, { apiVersion: "2025-10-29" });

const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET || null;

// Em produção, exigir webhook signing secret
if (process.env.NODE_ENV === "production" && !webhookSecret) {
  throw new Error("STRIPE_WEBHOOK_SECRET é obrigatório em production");
}

// Eventos que tratamos explicitamente
const HANDLED_EVENTS = new Set([
  "checkout.session.completed",
  "invoice.payment_succeeded",
  "invoice.paid",
  "invoice.payment_failed",
  "customer.subscription.updated",
  "customer.subscription.created",
  "customer.subscription.deleted",
  "payment_intent.succeeded",
  "charge.succeeded",
  "customer.updated",
]);

// Máximo de idade do evento (em ms). Eventos mais antigos são ignorados por segurança.
const MAX_EVENT_AGE_MS = 24 * 60 * 60 * 1000; // 24 horas

// Timeout wrapper para chamadas externas (Stripe)
const withTimeout = (p, ms) =>
  Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error("timeout")), ms))]);

// Timeout padrão para chamadas Stripe (ms)
const STRIPE_CALL_TIMEOUT_MS = 5000; // 5s

// Helper: executar operação Prisma e tratar violação de unique (P2002)
function isPrismaUniqueConstraintError(err) {
  return err instanceof Prisma.PrismaClientKnownRequestError && err.code === "P2002";
}

// Middleware: rota POST / (será montada como /webhook no server)
router.post("/", express.raw({ type: "application/json" }), async (req, res) => {
  try {
    const sig = req.headers["stripe-signature"];
    if (!sig && webhookSecret) {
      console.warn("Missing stripe-signature header");
      return res.status(400).send("Missing stripe-signature header");
    }

    let event;
    try {
      if (webhookSecret) {
        event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
      } else {
        // Somente DEV — inseguro em produção
        const text = Buffer.isBuffer(req.body) ? req.body.toString("utf8") : JSON.stringify(req.body);
        event = JSON.parse(text);
      }
    } catch (err) {
      console.error("Falha verificação webhook (signature):", err?.message ?? err);
      return res.status(400).send("Webhook signature verification failed");
    }

    // verificação simples e segura de idade e livemode
    if (!event || !event.id) {
      return res.status(400).send("Missing event.id");
    }
    if (event.created && Date.now() - event.created * 1000 > MAX_EVENT_AGE_MS) {
      console.warn("Evento muito antigo ignorado:", event.id);
      // marca como processed para evitar retries desnecessários
      try {
        await prisma.stripe_event.upsert({
          where: { event_id: event.id },
          update: { payload: event, processed: true, processed_at: new Date() },
          create: { event_id: event.id, payload: event, processed: true },
        });
      } catch (e) {
        // não falhar por causa do registro
      }
      return res.status(200).json({ received: true, note: "old_event_ignored" });
    }
    if (process.env.NODE_ENV === "production" && event.livemode !== true) {
      console.warn("Evento em modo de teste recebido em produção, ignorando:", event.id);
      return res.status(400).send("livemode mismatch");
    }

    // se evento não for do interesse, registra e retorna 200
    if (!HANDLED_EVENTS.has(event.type)) {
      console.info("Evento recebido (ignored):", event.type);
      try {
        await prisma.stripe_event.upsert({
          where: { event_id: event.id },
          update: { payload: event, processed: true, processed_at: new Date() },
          create: { event_id: event.id, payload: event, processed: true },
        });
      } catch (e) { /* ignore */ }
      return res.json({ received: true, note: "ignored_event_type" });
    }

    // idempotência: checar stripe_event
    try {
      const existing = await prisma.stripe_event.findUnique({ where: { event_id: event.id } });
      if (existing && existing.processed) {
        console.info("Evento já processado:", event.id);
        return res.json({ received: true, note: "already_processed" });
      }
      if (!existing) {
        // criar registro inicial (processed=false)
        try {
          await prisma.stripe_event.create({ data: { event_id: event.id, processed: false, payload: event } });
        } catch (e) {
          // corrida possível; continue
        }
      } else {
        // atualizar payload com tentativa mais recente
        try {
          await prisma.stripe_event.update({ where: { event_id: event.id }, data: { payload: event } });
        } catch (e) { /* ignore */ }
      }
    } catch (e) {
      console.error("Erro ao registrar stripe_event:", e?.message ?? e);
      return res.status(500).send("internal_error");
    }

    // FUNÇÕES AUXILIARES LOCAIS
    const toInt = (v) => {
      if (v === undefined || v === null) return null;
      const n = Number(v);
      return Number.isInteger(n) ? n : null;
    };

    async function safeRetrieveSubscription(id) {
      if (!id) return null;
      try {
        return await withTimeout(stripe.subscriptions.retrieve(String(id)), STRIPE_CALL_TIMEOUT_MS);
      } catch (e) {
        console.warn("Falha ao recuperar subscription (timeout/falha):", String(e.message ?? e));
        return null;
      }
    }

    async function safeRetrievePaymentIntent(id) {
      if (!id) return null;
      try {
        return await withTimeout(stripe.paymentIntents.retrieve(String(id)), STRIPE_CALL_TIMEOUT_MS);
      } catch (e) {
        console.warn("Falha ao recuperar PaymentIntent (timeout/falha):", String(e.message ?? e));
        return null;
      }
    }

    // resolve usuário local por metadata/email/stripe customer
    async function resolveLocalUser(tx, session, metadata = {}) {
      // 1) prefer explicit metadata user id (but still verify exists)
      const metaUserId = metadata?.userId || metadata?.user_id || metadata?.usuarioId || metadata?.user;
      if (metaUserId) {
        const idNum = Number(metaUserId);
        if (!Number.isNaN(idNum)) {
          try {
            const u = await tx.usuario.findUnique({ where: { id: idNum } });
            if (u) return u;
          } catch (e) { /* ignore */ }
        }
      }

      // 2) metadata email or session.customer_details.email
      const metaEmail = (metadata?.user_email || metadata?.userEmail || session?.customer_details?.email) ?? null;
      if (metaEmail) {
        try {
          const u = await tx.usuario.findUnique({ where: { email: String(metaEmail) } });
          if (u) return u;
        } catch (e) { /* ignore */ }
      }

      // 3) try via stripe customer
      const stripeCustomerId = session?.customer;
      if (stripeCustomerId) {
        try {
          const cus = await withTimeout(stripe.customers.retrieve(String(stripeCustomerId)), STRIPE_CALL_TIMEOUT_MS);
          const email = cus?.email ?? null;
          if (email) {
            try {
              const u = await tx.usuario.findUnique({ where: { email: String(email) } });
              if (u) return u;
            } catch (e) { /* ignore */ }
          }
        } catch (e) {
          console.warn("Falha ao recuperar Stripe customer:", String(e.message ?? e));
        }
      }

      return null;
    }

    // criar pacote de créditos com checagem de origem (tratando unique constraint)
    async function creditarPacotesSeguro(tx, id_usuario, origem, quantidade, opts = {}) {
      if (!origem) throw new Error("origem obrigatória");
      if (!id_usuario) throw new Error("id_usuario obrigatório");
      if (!quantidade || quantidade <= 0) return null;

      // tentativa direta de criar e capturar erro de unique (mais robusto em corrida)
      try {
        const pacote = await tx.pacote_creditos.create({
          data: { id_usuario, quantidade, origem, data_recebimento: new Date() },
        });
        // criar receita simbólica (não crítico)
        try {
          await tx.receita.create({
            data: { valor: 0.0, descricao: `Crédito automático (origem ${origem})`, id_usuario },
          });
        } catch (e) { /* não crítico */ }
        console.info("Pacote criado:", { pacoteId: pacote.id, origem, quantidade, ...opts });
        return pacote;
      } catch (e) {
        if (isPrismaUniqueConstraintError(e)) {
          console.info("Origem já existente -> pacote previamente creditado (ignorar):", origem);
          const existente = await tx.pacote_creditos.findFirst({ where: { origem } });
          return existente;
        }
        // rethrow para abortar a transação
        throw e;
      }
    }

    // resolver metadata e objetos autoritativos (subscription/invoice/session/payment_intent)
    async function resolveEventObjects(evt) {
      try {
        const type = evt.type;
        if (type === "checkout.session.completed") {
          const session = evt.data.object;
          if (session.subscription) {
            const sub = await safeRetrieveSubscription(session.subscription);
            return { session, subscription: sub, metadata: sub?.metadata || session.metadata || {} };
          }
          return { session, metadata: session.metadata || {} };
        } else if (type.startsWith("invoice.")) {
          const invoice = evt.data.object;
          if (invoice.subscription) {
            const sub = await safeRetrieveSubscription(invoice.subscription);
            return { invoice, subscription: sub, metadata: sub?.metadata || invoice.metadata || {} };
          }
          return { invoice, metadata: invoice.metadata || {} };
        } else if (type === "payment_intent.succeeded" || type === "charge.succeeded") {
          const obj = evt.data.object;
          return { obj, metadata: obj.metadata || {} };
        } else if (type.startsWith("customer.subscription.")) {
          const sub = evt.data.object;
          return { subscription: sub, metadata: sub.metadata || {} };
        } else {
          const obj = (evt.data && evt.data.object) || {};
          return { metadata: obj.metadata || {} };
        }
      } catch (e) {
        console.warn("resolveEventObjects falhou:", String(e?.message ?? e));
        return { metadata: {} };
      }
    }

    // --- PROCESSAMENTO dentro de transação ATÔMICA
    try {
      await prisma.$transaction(async (tx) => {
        const { session, subscription, invoice, obj, metadata } = await resolveEventObjects(event);

        // não confiar cegamente em metadata: use amount_received e DB para decisões críticas
        const planIdMeta = metadata?.planId || metadata?.plan_id || metadata?.planoId;
        const userIdMeta = metadata?.userId || metadata?.user_id || metadata?.usuarioId || metadata?.user;
        const planId = toInt(planIdMeta);
        const userIdFromMeta = toInt(userIdMeta);

        // --- checkout.session.completed
        if (event.type === "checkout.session.completed") {
          const sess = session || event.data.object;
          const stripeSubscriptionId = sess.subscription || (subscription && subscription.id) || null;
          const paymentIntentId = sess.payment_intent || null;

          // obter amount autoritativo (preferir PaymentIntent)
          let amountCents = sess.amount_total ?? null;
          let currency = sess.currency ?? null;
          if (paymentIntentId) {
            const pi = await safeRetrievePaymentIntent(paymentIntentId);
            if (pi && typeof pi.amount_received !== "undefined" && pi.amount_received !== null) {
              amountCents = pi.amount_received;
              currency = pi.currency ?? currency;
            }
          }
          const amountMajor = amountCents != null ? Number(amountCents) / 100.0 : null;

          // resolver usuário local (metadata/email/stripe customer)
          const resolvedUser = await resolveLocalUser(tx, sess, metadata);
          const resolvedUserId = resolvedUser ? resolvedUser.id : (userIdFromMeta || null);

          // persistir/atualizar compra (idempotente por stripe_session_id)
          const stripeSessionId = String(sess.id);
          let compra = await tx.compra.findFirst({ where: { stripe_session_id: stripeSessionId } });
          if (!compra) {
            const descricaoCompra = `Stripe checkout ${stripeSessionId}${sess.metadata?.local_order_id ? ` localOrder:${sess.metadata.local_order_id}` : ""}`;
            try {
              compra = await tx.compra.create({
                data: {
                  valor_pago: amountMajor != null ? Number(amountMajor.toFixed(2)) : null,
                  descricao: descricaoCompra,
                  stripe_session_id: stripeSessionId,
                  payment_intent_id: paymentIntentId || undefined,
                  id_usuario: resolvedUserId || null,
                  created_at: new Date(),
                },
              });
            } catch (e) {
              // se falha por unique constraint (corrida), recarregar
              if (isPrismaUniqueConstraintError(e)) {
                compra = await tx.compra.findFirst({ where: { stripe_session_id: stripeSessionId } });
              } else throw e;
            }
          } else {
            // atualizar campos faltantes se houver
            const updates = {};
            if ((compra.valor_pago == null || compra.valor_pago === 0) && amountMajor != null) updates.valor_pago = Number(amountMajor.toFixed(2));
            if (!compra.payment_intent_id && paymentIntentId) updates.payment_intent_id = paymentIntentId;
            if (!compra.id_usuario && resolvedUserId) updates.id_usuario = resolvedUserId;
            if (Object.keys(updates).length > 0) {
              await tx.compra.update({ where: { id: compra.id }, data: updates });
              compra = await tx.compra.findUnique({ where: { id: compra.id } });
            }
          }

          // Se é checkout de assinatura
          if (stripeSubscriptionId) {
            // atualizar/criar assinatura local -> criar somente se plano estiver validado
            let assinaturaDb = await tx.assinatura.findUnique({ where: { stripe_subscription_id: stripeSubscriptionId } });
            const now = new Date();
            const currentPeriodEnd = subscription && subscription.current_period_end ? new Date(subscription.current_period_end * 1000) : null;
            const status = subscription?.status ?? "active";

            if (!assinaturaDb) {
              // para criar automaticamente exigimos planId e userId na metadata e validação do price id
              if (!planId || !userIdFromMeta) {
                console.warn("Metadata insuficiente para criar assinatura local automaticamente. Registre manualmente ou via worker.", { session: stripeSessionId });
              } else {
                // validar price id da subscription contra plano local
                const stripePriceId = subscription?.items?.data?.[0]?.price?.id ?? null;
                const planoDb = await tx.plano.findUnique({ where: { id: planId } });
                if (!planoDb) {
                  console.warn("Plano local inexistente para planId metadata; abortando criação automática de assinatura.", { planId });
                } else if (planoDb.stripe_price_id && stripePriceId && planoDb.stripe_price_id !== stripePriceId) {
                  // mismatch -> possível manipulação do checkout
                  console.warn("Price mismatch. Não criar assinatura automaticamente.", { planId, planoStripe: planoDb.stripe_price_id, stripePriceId });
                } else {
                  // ok criar assinatura local
                  assinaturaDb = await tx.assinatura.create({
                    data: {
                      id_plano: planId,
                      id_dono: userIdFromMeta,
                      data_assinatura: now,
                      criado_em: now,
                      stripe_subscription_id: stripeSubscriptionId,
                      stripe_customer_id: sess.customer || subscription?.customer || null,
                      stripe_price_id: stripePriceId || undefined,
                      status,
                      current_period_end: currentPeriodEnd,
                      cancel_at_period_end: subscription?.cancel_at_period_end ?? false,
                      ativo: true,
                    },
                  });
                  console.info("Assinatura criada no DB:", assinaturaDb.id);
                }
              }
            } else {
              // atualizar assinatura existente
              await tx.assinatura.update({
                where: { id: assinaturaDb.id },
                data: {
                  stripe_customer_id: sess.customer || assinaturaDb.stripe_customer_id,
                  stripe_price_id: subscription?.items?.data?.[0]?.price?.id || assinaturaDb.stripe_price_id,
                  status,
                  current_period_end: currentPeriodEnd,
                  cancel_at_period_end: subscription?.cancel_at_period_end ?? assinaturaDb.cancel_at_period_end,
                  ativo: true,
                },
              });
              console.info("Assinatura existente atualizada:", assinaturaDb.id);
            }

            // creditar pacotes iniciais apenas se assinaturaDb existir e plano configurado
            if (assinaturaDb) {
              const planoDb = await tx.plano.findUnique({ where: { id: assinaturaDb.id_plano } });
              const quantidade = (planoDb && Number(planoDb.quantidade_credito_mensal) > 0) ? Number(planoDb.quantidade_credito_mensal) : 0;
              const origem = `stripe:subscription:${stripeSubscriptionId}:checkout_session:${stripeSessionId}`;
              if (quantidade > 0) {
                await creditarPacotesSeguro(tx, assinaturaDb.id_dono, origem, quantidade, { planoId: assinaturaDb.id_plano });
              }
            }
          } else {
            // compra avulsa -> criar pacote conforme preco_do_credito (NÃO confiar em metadata.credit_qty)
            if (resolvedUserId && amountMajor != null) {
              try {
                const cfg = await tx.config_sistema.findFirst({ orderBy: { id: "desc" } });
                const precoDoCredito = cfg && cfg.preco_do_credito != null ? Number(cfg.preco_do_credito.toString()) : null;
                if (precoDoCredito && precoDoCredito > 0) {
                  const quantidade = Math.floor(amountMajor / precoDoCredito);
                  if (quantidade > 0) {
                    const localOrderId = sess.metadata?.local_order_id ?? null;
                    const origem = `stripe:session:${stripeSessionId}${localOrderId ? `:local:${localOrderId}` : ""}`;
                    await creditarPacotesSeguro(tx, resolvedUserId, origem, quantidade, { compraId: compra?.id });
                    // gravar receita com valor pago (não crítico)
                    try {
                      await tx.receita.create({
                        data: {
                          valor: Number(amountMajor.toFixed(2)),
                          descricao: `Receita via Stripe session ${stripeSessionId}`,
                          id_usuario: resolvedUserId,
                        },
                      });
                    } catch (e) { /* ignore */ }
                  } else {
                    console.info("Valor insuficiente para gerar créditos com preco configurado.", { amountMajor, precoDoCredito });
                  }
                } else {
                  console.warn("Preco do credito indisponível; pacotes não serão criados automaticamente.");
                }
              } catch (e) {
                console.warn("Erro ao calcular/criar pacote de credits compra avulsa:", String(e?.message ?? e));
              }
            } else {
              if (!resolvedUserId) console.warn("Usuário não identificado para compra avulsa (metadata/stripe).", { sessionId: stripeSessionId });
              if (amountMajor == null) console.warn("Valor da transação desconhecido para session:", { sessionId: stripeSessionId });
            }
          }

          // preparar payload para email/recibo — NÃO enviar aqui. Anexaremos ao evento para post-process
          if (resolvedUserId && typeof amountMajor === "number") {
            // adiciona instrução para worker no payload salvo (não realizamos IO de email aqui)
            event._email_job = {
              to_user_id: resolvedUserId,
              session_id: stripeSessionId,
              amount: Number(amountMajor.toFixed(2)),
              currency: currency ?? null,
              description: compra?.descricao ?? `Stripe checkout ${stripeSessionId}`,
              created_at: new Date().toISOString(),
            };
          }
        } // end checkout.session.completed

        // --- invoice.payment_succeeded / invoice.paid
        else if (event.type === "invoice.payment_succeeded" || event.type === "invoice.paid") {
          const inv = invoice || event.data.object;
          const stripeSubscriptionId = inv.subscription || (subscription && subscription.id) || null;
          if (!stripeSubscriptionId) {
            console.info("invoice.payment_succeeded sem subscription");
          } else {
            const assinaturaDb = await tx.assinatura.findUnique({ where: { stripe_subscription_id: stripeSubscriptionId } });
            if (!assinaturaDb) {
              console.warn("Nenhuma assinatura local para subscription:", stripeSubscriptionId);
            } else {
              const periodEnd = subscription && subscription.current_period_end ? new Date(subscription.current_period_end * 1000)
                : (inv.lines?.data?.[0]?.period?.end ? new Date(inv.lines.data[0].period.end * 1000) : null);

              await tx.assinatura.update({
                where: { id: assinaturaDb.id },
                data: { status: subscription?.status ?? "active", current_period_end: periodEnd || undefined, ativo: true },
              });

              // creditar pacotes (renovação)
              const planoDb = await tx.plano.findUnique({ where: { id: assinaturaDb.id_plano } });
              const quantidade = (planoDb && Number(planoDb.quantidade_credito_mensal) > 0) ? Number(planoDb.quantidade_credito_mensal) : 0;
              const origem = `stripe:subscription:${stripeSubscriptionId}:invoice:${inv.id}`;
              if (quantidade > 0) {
                await creditarPacotesSeguro(tx, assinaturaDb.id_dono, origem, quantidade, { assinaturaId: assinaturaDb.id });
              }
            }
          }
        }

        // --- invoice.payment_failed
        else if (event.type === "invoice.payment_failed") {
          const inv = invoice || event.data.object;
          const stripeSubscriptionId = inv.subscription || (subscription && subscription.id) || null;
          if (stripeSubscriptionId) {
            const assinaturaDb = await tx.assinatura.findUnique({ where: { stripe_subscription_id: stripeSubscriptionId } });
            if (assinaturaDb) {
              await tx.assinatura.update({ where: { id: assinaturaDb.id }, data: { status: "past_due" } });
              await tx.logs_usuario.create({
                data: { id_do_usuario: assinaturaDb.id_dono, acao_no_sistema: `Falha de pagamento para assinatura ${assinaturaDb.id} (subscription ${stripeSubscriptionId}, invoice ${inv.id})` },
              });
            }
          }
        }

        // --- subscription.updated/created/deleted
        else if (event.type === "customer.subscription.updated" || event.type === "customer.subscription.created") {
          const sub = subscription || event.data.object;
          const assinaturaDb = await tx.assinatura.findUnique({ where: { stripe_subscription_id: sub.id } });
          if (assinaturaDb) {
            await tx.assinatura.update({
              where: { id: assinaturaDb.id },
              data: {
                status: sub.status,
                cancel_at_period_end: sub.cancel_at_period_end ?? assinaturaDb.cancel_at_period_end,
                current_period_end: sub.current_period_end ? new Date(sub.current_period_end * 1000) : assinaturaDb.current_period_end,
              },
            });
          }
        } else if (event.type === "customer.subscription.deleted" || event.type === "customer.subscription.cancelled") {
          const sub = subscription || event.data.object;
          const assinaturaDb = await tx.assinatura.findUnique({ where: { stripe_subscription_id: sub.id } });
          if (assinaturaDb) {
            await tx.assinatura.update({
              where: { id: assinaturaDb.id },
              data: { ativo: false, status: sub.status ?? "canceled", canceled_at: sub.canceled_at ? new Date(sub.canceled_at * 1000) : new Date(), cancel_at_period_end: false },
            });
          }
        }

        // --- payment_intent.succeeded / charge.succeeded -> tentar reconciliar compra
        else if (event.type === "payment_intent.succeeded" || event.type === "charge.succeeded") {
          const o = obj || event.data.object;
          const paymentIntentId = o.id || o.payment_intent || null;
          const amountReceived = o.amount_received ?? o.amount ?? null;
          if (paymentIntentId) {
            try {
              const existingCompra = await tx.compra.findFirst({ where: { payment_intent_id: String(paymentIntentId) } });
              if (existingCompra && (existingCompra.valor_pago == null || existingCompra.valor_pago === 0) && typeof amountReceived !== "undefined" && amountReceived !== null) {
                const amountMajor = Number(amountReceived) / 100.0;
                await tx.compra.update({ where: { id: existingCompra.id }, data: { valor_pago: Number(amountMajor.toFixed(2)) } });
                console.info("Compra reconciliada a partir de payment_intent:", existingCompra.id);
              }
            } catch (e) {
              console.warn("Falha reconciliar PaymentIntent -> compra:", String(e?.message ?? e));
            }
          }
        } // fim eventos tratados

        // Se preparamos trabalho adicional (email), atualizar payload salvo para que worker pegue
        if (event._email_job) {
          try {
            // atualizar stripe_event.payload para incluir instrução de post-process
            await tx.stripe_event.updateMany({
              where: { event_id: event.id },
              data: { payload: event },
            });
          } catch (e) {
            console.warn("Falha ao anexar email_job ao stripe_event (não crítico):", String(e?.message ?? e));
          }
        }

        // marcar processed=true apenas após tudo ok
        await tx.stripe_event.updateMany({
          where: { event_id: event.id },
          data: { processed: true, processed_at: new Date() },
        });
      }); // end transaction

      // sucesso
      return res.json({ received: true });
    } catch (err) {
      console.error("Erro processando webhook (transação abortada):", String(err?.message ?? err));
      // NÃO marcar processed=true -> Stripe irá reenviar
      return res.status(500).send("internal_error");
    }
  } catch (outerErr) {
    console.error("Erro no handler do webhook:", String(outerErr?.message ?? outerErr));
    return res.status(500).send("internal_error");
  }
});

export default router;
